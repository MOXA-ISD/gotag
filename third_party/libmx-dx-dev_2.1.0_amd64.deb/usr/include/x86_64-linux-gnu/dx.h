/*  Copyright (C) MOXA Inc. All rights reserved.

    This software is distributed under the terms of the
    MOXA License.  See the file COPYING-MOXA for details.
*/


#ifndef _DX_H_
#define _DX_H_

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

typedef enum
{
    SHM_STATUS_IDLE = 0,
    SHM_STATUS_WRITING = 1
} shm_status;

typedef enum
{
    DX_RET_OK = 0,
    DX_RET_FAIL = -1
} dx_ret;

typedef enum
{
    DX_TAG_VALUE_TYPE_FAIL = -1,

    DX_TAG_VALUE_TYPE_BOOLEAN = 0,
    DX_TAG_VALUE_TYPE_INT8,
    DX_TAG_VALUE_TYPE_INT16,
    DX_TAG_VALUE_TYPE_INT32,
    DX_TAG_VALUE_TYPE_INT64,
    DX_TAG_VALUE_TYPE_UINT8,
    DX_TAG_VALUE_TYPE_UINT16,
    DX_TAG_VALUE_TYPE_UINT32,
    DX_TAG_VALUE_TYPE_UINT64,
    DX_TAG_VALUE_TYPE_FLOAT,
    DX_TAG_VALUE_TYPE_DOUBLE,
    DX_TAG_VALUE_TYPE_STRING,
    DX_TAG_VALUE_TYPE_BYTEARRAY,
    DX_TAG_VALUE_TYPE_RAW,

    DX_TAG_VALUE_TYPE_TOTAL,
} dx_tag_value_type;

/* dx tag value type string */
#define DX_TAG_VALUE_TYPE_BOOLEAN_STR   "boolean"
#define DX_TAG_VALUE_TYPE_INT8_STR      "int8"
#define DX_TAG_VALUE_TYPE_INT16_STR     "int16"
#define DX_TAG_VALUE_TYPE_INT32_STR     "int32"
#define DX_TAG_VALUE_TYPE_INT64_STR     "int64"
#define DX_TAG_VALUE_TYPE_UINT8_STR     "uint8"
#define DX_TAG_VALUE_TYPE_UINT16_STR    "uint16"
#define DX_TAG_VALUE_TYPE_UINT32_STR    "uint32"
#define DX_TAG_VALUE_TYPE_UINT64_STR    "uint64"
#define DX_TAG_VALUE_TYPE_FLOAT_STR     "float"
#define DX_TAG_VALUE_TYPE_DOUBLE_STR    "double"
#define DX_TAG_VALUE_TYPE_STRING_STR    "string"
#define DX_TAG_VALUE_TYPE_BYTEARRAY_STR "bytearray"
#define DX_TAG_VALUE_TYPE_RAW_STR       "raw"

typedef union
{
    bool        boolean;   /**< boolean  */
    int8_t      i8;     /**< signed integer 8  */
    int16_t     i16;    /**< signed integer 16 */
    int32_t     i32;    /**< signed integer 32 */
    int64_t     i64;    /**< signed integer 64 */
    uint8_t     u8;     /**< unsigned integer 8 */
    uint16_t    u16;    /**< unsigned integer 16 */
    uint32_t    u32;    /**< unsigned integer 32 */
    uint64_t    u64;    /**< unsigned integer 64 */
    float       f;      /**< float */
    double      d;      /**< doube */
    struct
    {
        char    *s;     /**< string */
        uint16_t sl;    /**< string length */
    };
    struct
    {
        char     *b;    /**< bytearray */
        uint16_t bl;    /**< bytearray length */
    };
    struct
    {
        char     *rp;   /**< raw payload */
        uint16_t rl;    /**< rawpayload length */
    };
} dx_tag_value;

#define DX_MAX_VALUE_SIZE 4000
#define DX_MAX_DICT_NUM 1024
#define DX_BIT_NUM_IN_BYTE 8
#define DX_LOG_8_BASE_2 3

#if (DX_MAX_DICT_NUM & (DX_MAX_DICT_NUM - 1)) != 0
#error "DX_MAX_DICT_NUM must be a power of two"
#endif

typedef struct _dx_t dx_t;
typedef struct _dx_tag_t dx_tag_t;
typedef struct _dx_shm_t dx_shm_t;

struct _dx_write_info
{
    char payload[DX_MAX_DICT_NUM / DX_BIT_NUM_IN_BYTE];
};
typedef struct _dx_write_info dx_write_info;

struct _dx_dict_entry_t
{
    dx_tag_t *tag;
    struct _dx_dict_entry_t *next;
};
typedef struct _dx_dict_entry_t dx_dict_entry_t;

typedef void (* DX_CALLBACK)(dx_t *dx, dx_write_info *write_info, void *dx_user_data);
typedef void *(*DX_MALLOC_FUNC)(size_t);
typedef void (*DX_FREE_FUNC)(void *);

#define DX_DECODE(payload, byte_offset, bit_offset) (payload[byte_offset] & (1 << bit_offset))
#define DX_ENCODE(payload, byte_offset, bit_offset) (payload[byte_offset] |= (1 << bit_offset))

#define DX_BYTE_OFFSET(offset) (offset >> DX_LOG_8_BASE_2)
#define DX_BIT_OFFSET(offset) (offset & (DX_BIT_NUM_IN_BYTE - 1))

/*
* Put DX_EACH_TAG_HEADER() and DX_EACH_TAG_FOOTER() in the callback,
* updated tag event would occur in middle.
*/
#define DX_EACH_TAG_HEADER(dx, write_info, cur_tag) \
    dx_dict_entry_t *___entry; \
    int __offset;\
    for(__offset = 0; __offset < DX_MAX_DICT_NUM; ++__offset) \
    { \
        if(DX_DECODE(write_info->payload, DX_BYTE_OFFSET(__offset), DX_BIT_OFFSET(__offset)) > 0) \
        { \
            ___entry = dx_lookup_head(dx, __offset); \
            while (___entry) \
            { \
                if((___entry->tag) && (dx_tag_has_read(___entry->tag) == false))\
                { \
                    cur_tag = ___entry->tag;\
                    do{


#define DX_EACH_TAG_FOOTER() \
    }while(0);\
    } \
    ___entry = ___entry->next; \
    } \
    } \
    }


/**
 * @brief    Create dx handle
 *
 * @param    name   Server name. The name should be global unique. Provider name
 *                      could be considered.
 *
 * @param    callback   Notify function callback
 *
 * @return    A @c dx_t* to the newly created dx or @c NULL in case an error occurs.
 */
dx_t *dx_new(const char *name, DX_CALLBACK callback);



/**
 * @brief    Destroy dx handle
 *
 * @param    dx dx handle
 *
 * @return    @c DX_RET_OK if the API call is successful or @c DX_RET_FAIL if fails
 */
dx_ret dx_destroy(dx_t *dx);

/**
 * @brief    Set dx user data
 *
 * @param    dx             dx handle
 * @param    dx_user_data       user data in dx scope
 *
 * @return    @c DX_RET_OK if the API call is successful or @c DX_RET_FAIL if fails
 */
dx_ret dx_set_user_data(dx_t *dx, void *dx_user_data);

/**
 * @brief    Get dx user data
 *
 * @param    dx dx handle
 *
 * @return    @c dx_user_data if the API call is successful or @c NULL if fails
 */
void *dx_get_user_data(dx_t *dx);

/**
 * @brief    Lookup entry head
 *
 * @param    dx     dx handle
 * @param    hash       hash index
 *
 * @return    @c dx_dict_entry_t* if the API call is successful or @c NULL if emtpy or fails
 */
dx_dict_entry_t *dx_lookup_head(dx_t *dx, uint32_t hash);

/**
 * @brief    Create dx tag handle in provider
 *
 * @param    dx         dx handle
 * @param    topic          topic of tag
 * @param    value_type     tag value type
 * @param    value_size     tag value size (bytes).
 *                                    Ignore this param if value type has fixed length (boolen, int8, int16,...uint64, float, double).
 *                                    Only use this param if value type has variable length (raw, bytearray, string).
 *
 * @return    A @c dx_tag_t* to the newly created dx tag or @c NULL in case an
 *          error occurs.
 */
dx_tag_t *dx_tag_provider_new(dx_t *dx, const char *topic, dx_tag_value_type value_type, uint32_t value_size);

/**
 * @brief    Create dx tag handle in consumer
 *
 * @param    dx         dx handle
 * @param    topic          topic of tag
 *                                    Only use this param if value type has variable length (raw, bytearray, string).
 *
 * @return    A @c dx_tag_t* to the newly created dx tag or @c NULL in case an
 *          error occurs.
 */
dx_tag_t *dx_tag_consumer_new(dx_t *dx, const char *topic);

/**
 * @brief    Destroy dx tag handle
 *
 * @param    dx         dx handle
 * @param    tag    dx tag handle
 *
 * @return    @c DX_RET_OK if the API call is successful or @c DX_RET_FAIL if fails
 */
dx_ret dx_tag_destroy(dx_t *dx, dx_tag_t *tag);

/**
 * @brief    Set dx tag user data
 *
 * @param    tag                dx tag handle
 * @param    tag_user_data      user data in tag scope
 *
 * @return    @c DX_RET_OK if the API call is successful or @c DX_RET_FAIL if fails
 */
dx_ret dx_tag_set_user_data(dx_tag_t *tag, void *tag_user_data);

/**
 * @brief    Get dx tag user data
 *
 * @param    tag    dx tag handle
 *
 * @return    @c tag_user_data if the API call is successful or @c NULL if fails
 */
void *dx_tag_get_user_data(dx_tag_t *tag);

/**
 * @brief    Read dx tag value
 *
 * @param    tag                dx tag handle
 * @param    value          output memory, should not be NULL
 * @param    value_size     memory size (bytes)
 *
 * @return    @c the number of bytes read if the API call is successful or @c (-1) if fails or tag info has not been set
 */
int dx_tag_read(dx_tag_t *tag, void *value, uint32_t value_size);

/**
 * @brief    Read dx tag value instantly
 *
 * @param    topic          topic of tag
 * @param    value          output memory, should not be NULL
 * @param    value_size     output memory size (bytes)
 * @param    timestamp_us   output tag updated time from tag writer (us)
 *
 * @return    @c the number of bytes read if the API call is successful or @c (-1) if fails or tag info has not been set
 */
int dx_tag_instant_read(const char *topic, void **value, dx_tag_value_type *value_type, uint32_t *value_size, uint64_t *timestamp_us);

/**
 * @brief    Read dx tag value with timestamp
 *
 * @param    tag                    dx tag handle
 * @param    value                  output memory, should not be NULL
 * @param    value_size         memory size (bytes)
 * @param    timestamp_us       output tag updated time from tag writer (us)
 *
 * @return    @c the number of bytes read if the API call is successful or @c (-1) if fails or tag info has not been set
 */
int dx_tag_read_with_timestamp(dx_tag_t *tag, void *value, uint32_t value_size, uint64_t *timestamp_us);

/**
 * @brief    Write dx tag value
 *
 * @param    dx             dx handle
 * @param    tag            dx tag handle
 * @param    value      input memory, should not be NULL
 * @param    value_size memory size (bytes)
 *
 * @return    @c the number of bytes written if the API call is successful or @c (-1) if fails or tag info has not been set
 */
int dx_tag_write(dx_t *dx, dx_tag_t *tag, void *value, uint32_t value_size);

/**
 * @brief    Write dx tag value with timestamp
 *
 * @param    dx                     dx handle
 * @param    tag                    dx tag handle
 * @param    value                  input memory, should not be NULL
 * @param    value_size         memory size (bytes)
 * @param    timestamp_us       output tag updated time which is defined by writer itself (us)
 *
 * @return    @c the number of bytes written if the API call is successful or @c (-1) if fails or tag info has not been set
 */
int dx_tag_write_with_timestamp(dx_t *dx, dx_tag_t *tag, void *value, uint32_t value_size, uint64_t timestamp_us);

/**
 * @brief    Write dx tag value with timestamp instantly
 *
 * @param    topic          topic of tag
 * @param    value          input memory, should not be NULL
 * @param    value_size     memory size (bytes)
 * @param    timestamp_us   tag updated time which is defined by writer itself (us)
 *
 * @return    @c the number of bytes written if the API call is successful or @c (-1) if fails or tag info has not been set
 */
int dx_tag_instant_write(dx_t *dx, const char *topic, void *value, dx_tag_value_type value_type, uint32_t value_size, uint64_t timestamp_us);

/**
 * @brief    Writer should notify other modules after tags are written
 *
 * @param    dx     dx handle
 *
 * @return    @c tag_user_data if the API call is successful or @c NULL if fails
 */
dx_ret dx_tag_notify(dx_t *dx);

/**
 * @brief    Get tag topic
 *
 * @param    tag        dx tag handle
 *
 * @return    @c topic if the API call is successful or @c NULL if fails
 */
const char *dx_tag_get_topic(dx_tag_t *tag);


/**
 * @brief    Get dynamic value type and value size
 *
 * @param    tag                dx tag handle
 * @param    value_type    output value type. NULL is acceptable is value type is unused.
 * @param    value_size    output value size. NULL is acceptable is value size is unused.
 *
 *
 * @return    A @c 0 if is successful or @c (-1) is fails or value info has not been set.
 *          Value info should set by dx_tag_provider_new(). Value info is valid after setting.
 *
 */
dx_ret dx_tag_get_value_info(dx_tag_t *tag, dx_tag_value_type *value_type, uint32_t *value_size);


/**
 * @brief    Reader check if the tag has been read after the tag is written by writer
 *
 * @param    tag        dx tag handle
 *
 * @return    @c false if tag has not been read or @c true if has been read or fails
 */
bool dx_tag_has_read(dx_tag_t *tag);

/**
 * @brief    Get current timestamp (us)
 *
 * @return    @c timestamp is current timestamp (us)
 */
uint64_t dx_get_timestamp_us(void);

/**
 * @brief    Get real value size (byte)
 *
 * @param    value_type                 value size
 * @param    variable_value_size            value size of variable length type
 *                                              Ignore this param if value type has fixed length (boolen, int8, int16,...uint64, float, double).
 *                                              Only use this param if value type has variable length (raw, bytearray, string).
 *
 * @return    @c size if is successful or @c 0 if fails
 */
uint32_t dx_get_value_size(dx_tag_value_type value_type, uint32_t variable_value_size);

/**
 * @brief    Transfer dx tag value type string to dx tag value type
 *
 * @param    type_str        dx tag value type string:
 *                       DX_TAG_VALUE_TYPE_BOOLEAN_STR,
 *                       DX_TAG_VALUE_TYPE_INT8_STR,
 *                       DX_TAG_VALUE_TYPE_INT16_STR,
 *                       DX_TAG_VALUE_TYPE_INT32_STR,
 *                       DX_TAG_VALUE_TYPE_INT64_STR,
 *                       DX_TAG_VALUE_TYPE_UINT8_STR,
 *                       DX_TAG_VALUE_TYPE_UINT16_STR,
 *                       DX_TAG_VALUE_TYPE_UINT32_STR,
 *                       DX_TAG_VALUE_TYPE_UINT64_STR,
 *                       DX_TAG_VALUE_TYPE_FLOAT_STR,
 *                       DX_TAG_VALUE_TYPE_DOUBLE_STR,
 *                       DX_TAG_VALUE_TYPE_STRING_STR,
 *                       DX_TAG_VALUE_TYPE_BYTEARRAY_STR,
 *                       DX_TAG_VALUE_TYPE_RAW_STR
 *
 * @return    @c dx_tag_value_type   if is successful or @c (-1) if fails
 */
dx_tag_value_type dx_str2type(const char *type_str);


/**
 * @brief    Transfer dx tag value type to dx tag value type string
 *
 * @param    value_type        dx tag value type:
 *                       DX_TAG_VALUE_TYPE_BOOLEAN
 *                       DX_TAG_VALUE_TYPE_INT8,
 *                       DX_TAG_VALUE_TYPE_INT16,
 *                       DX_TAG_VALUE_TYPE_INT32,
 *                       DX_TAG_VALUE_TYPE_INT64,
 *                       DX_TAG_VALUE_TYPE_UINT8,
 *                       DX_TAG_VALUE_TYPE_UINT16,
 *                       DX_TAG_VALUE_TYPE_UINT32,
 *                       DX_TAG_VALUE_TYPE_UINT64,
 *                       DX_TAG_VALUE_TYPE_FLOAT,
 *                       DX_TAG_VALUE_TYPE_DOUBLE,
 *                       DX_TAG_VALUE_TYPE_STRING,
 *                       DX_TAG_VALUE_TYPE_BYTEARRAY,
 *                       DX_TAG_VALUE_TYPE_RAW
 *
 * @return    @c dx tag value type string if is successful or @c NULL if fails
 */
const char *dx_type2str(dx_tag_value_type value_type);

#endif
