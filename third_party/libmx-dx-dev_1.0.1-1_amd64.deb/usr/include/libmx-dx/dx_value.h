/*  Copyright (C) MOXA Inc. All rights reserved.

    This software is distributed under the terms of the
    MOXA License.  See the file COPYING-MOXA for details.
*/

#ifndef __DX_VALUE_H__
#define __DX_VALUE_H__

typedef union
{
    int8_t      i8;     /**< signed integer 8  */
    int16_t     i16;    /**< signed integer 16 */
    int32_t     i32;    /**< signed integer 32 */
    int64_t     i64;    /**< signed integer 64 */
    int64_t     i;      /**< signed integer 64 */   /* deprecated */
    uint8_t     u8;     /**< unsigned integer 8 */
    uint16_t    u16;    /**< unsigned integer 16 */
    uint32_t    u32;    /**< unsigned integer 32 */
    uint64_t    u64;    /**< unsigned integer 64 */
    uint64_t    u;      /**< unsigned integer 64 */ /* deprecated */
    float       f;      /**< float */
    double      d;      /**< doube */
    struct
    {
        char    *s;     /**< String */
        uint16_t sl;    /**< String length */
    };
    struct
    {
        char     *b;    /**< bytearray */
        uint16_t bl;    /**< bytearray length */
    };
    struct
    {
        char     *rp;   /**< raw payload */
        uint16_t rl;    /**< rawpayload length */
    };
} DX_TAG_VALUE;

typedef enum
{
    DX_TAG_VALUE_TYPE_BOOLEAN = 0,
    DX_TAG_VALUE_TYPE_INT8,
    DX_TAG_VALUE_TYPE_INT16,
    DX_TAG_VALUE_TYPE_INT32,
    DX_TAG_VALUE_TYPE_INT64,
    DX_TAG_VALUE_TYPE_INT,          // deprecated
    DX_TAG_VALUE_TYPE_UINT8,
    DX_TAG_VALUE_TYPE_UINT16,
    DX_TAG_VALUE_TYPE_UINT32,
    DX_TAG_VALUE_TYPE_UINT64,
    DX_TAG_VALUE_TYPE_UINT,         // deprecated
    DX_TAG_VALUE_TYPE_FLOAT,
    DX_TAG_VALUE_TYPE_DOUBLE,
    DX_TAG_VALUE_TYPE_STRING,
    DX_TAG_VALUE_TYPE_BYTEARRAY,
    DX_TAG_VALUE_TYPE_RAW = 0xFF,
} DX_TAG_VALUE_TYPE;


#define DX_TAG_VALUE_TYPE_BOOLEAN_STR   "boolean"
#define DX_TAG_VALUE_TYPE_INT8_STR      "int8"
#define DX_TAG_VALUE_TYPE_INT16_STR     "int16"
#define DX_TAG_VALUE_TYPE_INT32_STR     "int32"
#define DX_TAG_VALUE_TYPE_INT64_STR     "int64"
#define DX_TAG_VALUE_TYPE_INT_STR       "int"           // deprecated
#define DX_TAG_VALUE_TYPE_UINT8_STR     "uint8"
#define DX_TAG_VALUE_TYPE_UINT16_STR    "uint16"
#define DX_TAG_VALUE_TYPE_UINT32_STR    "uint32"
#define DX_TAG_VALUE_TYPE_UINT64_STR    "uint64"
#define DX_TAG_VALUE_TYPE_UINT_STR      "uint"          // deprecated
#define DX_TAG_VALUE_TYPE_FLOAT_STR     "float"
#define DX_TAG_VALUE_TYPE_DOUBLE_STR    "double"
#define DX_TAG_VALUE_TYPE_STRING_STR    "string"
#define DX_TAG_VALUE_TYPE_BYTEARRAY_STR "byte-array"
#define DX_TAG_VALUE_TYPE_RAW_STR       "raw"


#endif /* __DX_VALUE_H__ */
