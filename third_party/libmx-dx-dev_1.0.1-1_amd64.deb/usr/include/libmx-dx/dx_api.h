/*  Copyright (C) MOXA Inc. All rights reserved.

    This software is distributed under the terms of the
    MOXA License.  See the file COPYING-MOXA for details.
*/

#ifndef __DX_API_H__
#define __DX_API_H__

#include <stdint.h>
#include <libmx-dx/dx_value.h>
#include <pthread.h>

typedef enum
{
    DX_TAG_OK = 0,
    DX_TAG_MALLOC_FAIL        = -1,
    DX_TAG_CREATE_THREAD_FAIL = -2,
    DX_TAG_CREATE_FAIL        = -3,
    DX_TAG_GET_FAIL           = -4,
    DX_TAG_SET_FAIL           = -5,
    DX_TAG_SUB_FAIL           = -6,
    DX_TAG_PUB_FAIL           = -7,
    DX_TAG_PUB_MAP_FAIL       = -8,
    DX_TAG_PUB_ASSEMBLE_FAIL  = -9,
    DX_TAG_TRY_AGAIN          = -10,
    DX_TAG_FAIL               = -99,
} DX_TAG_RET;

typedef struct DX_TAG_OBJ_t
{
    uint64_t            timestamp;
    char                *tag;
    DX_TAG_VALUE_TYPE   val_type;
    DX_TAG_VALUE        val;
    void                *user_data;

} DX_TAG_OBJ, *DX_TAG_OBJ_P;

typedef void (*DX_TAG_SUB_CB)(DX_TAG_OBJ *dx_tag_obj, uint16_t obj_cnt, void *user_data);

typedef struct DX_TAG_CLIENT_t DX_TAG_CLIENT, *DX_TAG_CLIENT_P;

DX_TAG_CLIENT* dx_tag_client_init(char* module_name, DX_TAG_SUB_CB sub_cb);

DX_TAG_RET dx_tag_destroy(DX_TAG_CLIENT_P client);

DX_TAG_RET dx_tag_set_user_obj(DX_TAG_CLIENT_P client, void *obj);

DX_TAG_RET dx_tag_sub(DX_TAG_CLIENT_P client, char *tag, void *user_data);

DX_TAG_RET dx_tag_pub(DX_TAG_CLIENT_P client,
                      char *tag,
                      DX_TAG_VALUE_TYPE val_type,
                      DX_TAG_VALUE val,
                      uint64_t ts);

DX_TAG_RET dx_tag_multi_pub(DX_TAG_CLIENT_P client, DX_TAG_OBJ* dx_obj, uint32_t dx_obj_cnt);

DX_TAG_RET dx_tag_get(DX_TAG_CLIENT_P client,
                      char *tag,
                      DX_TAG_VALUE_TYPE *val_type,
                      DX_TAG_VALUE *val,
                      uint64_t *ts);

DX_TAG_VALUE_TYPE dx_tag_str2type(const char* type);

#endif /* __DX_API_H__ */