/*  Copyright (C) MOXA Inc. All rights reserved.

    This software is distributed under the terms of the
    MOXA License.  See the file COPYING-MOXA for details.
*/

#ifndef __BINDER_H__
#define __BINDER_H__

#include <stdint.h>
#include <libmx-dx/dx_value.h>
#include <parson.h>

#define BINDER_CONF_DEFAULT_FILE    "/etc/thanos/mxthanos/binder/default/binder.conf"
#define BINDER_CONF_PATH            "/etc/thanos/mxthanos/binder/"
#define BINDER_CONF_FILE            "binder.conf"

#define BINDER_MAX_RULE_COUNT   100

typedef enum
{
    BINDER_OK             = 0,
    BINDER_FAIL           = -1,
    BINDER_MALLOC_FAIL    = -2,
    BINDER_MAP_FAIL       = -3,
    BINDER_OPEN_CONF_FAIL = -4,
    BINDER_PARM_INVALID   = -5,

} BINDER_RET;

typedef struct BINDER_TAG_INFO_t
{
    char *tag;
    uint16_t tag_len;
    DX_TAG_VALUE_TYPE data_type;
    uint32_t data_quantity;
    struct BINDER_TAG_INFO_t *next;

} BINDER_TAG_INFO, *BINDER_TAG_INFO_P;

typedef struct BINDER_RULE_t
{
    BINDER_TAG_INFO *src;
    BINDER_TAG_INFO *dst;
    struct BINDER_RULE_t *next;

} BINDER_RULE, *BINDER_RULE_p;


BINDER_RET binder_tag_couple(BINDER_TAG_INFO tag_a_info, BINDER_TAG_INFO tag_b_info);
BINDER_RET binder_tag_decouple(char *tag_a, char *tag_b);

JSON_Value *binder_conf_init();
BINDER_RET binder_conf_sync(JSON_Value *root_val);
BINDER_RET binder_conf_free(JSON_Value *root_val);

/**
 *  \brief  Add a new tag infomation.
 *  \param[in]  head	the head pointer of link list
 *  \retval NULL	fail
 *  \retval not NULL	a new tag infomation which add to the end of the link list. Please use binder_taginfo_free() this tag infomation.
 *
 *  Add a new tag infomation.
 */
BINDER_TAG_INFO_P binder_taginfo_add(BINDER_TAG_INFO_P *head);

/**
 *  \brief  Remove specific tag infomation from link list.
 *  \param[in]  head	the head pointer of link list
 *  \param[in]  taginfo		the specific tag which would be removed from the link list
 *  \retval BINDER_OK		
 *  \retval BINDER_FAIL	
 *
 *  Remove specific tag infomation from link list.
 */
BINDER_RET binder_taginfo_remove(BINDER_TAG_INFO_P *head, BINDER_TAG_INFO_P taginfo);


/**
 *  \brief  Free specific tag infomation.
 *  \param[in]  taginfo		the specific tag which would be deleted in the link list
 *  \retval BINDER_OK		
 *  \retval BINDER_FAIL	
 *
 *  Free specific tag infomation.
 */
BINDER_RET binder_taginfo_free(BINDER_TAG_INFO_P taginfo);


/**
 *  \brief  Get destination tags infomation by the source tag name.
 *  \param[in]  src_tag	 src tag name
 *  \retval NULL	no dst tag exist or fail 
 *  \retval not NULL	target dst tags infomation. Please use binder_taginfo_free() to free all taginfo in this link list.
 *
 *  Get destination tags infomation by the source tag name.
 */
BINDER_TAG_INFO_P binder_taginfo_search_dst(const char *src_tag);


	
#endif /* __BINDER_H__ */
