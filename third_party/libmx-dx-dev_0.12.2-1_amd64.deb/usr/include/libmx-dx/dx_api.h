/*  Copyright (C) MOXA Inc. All rights reserved.

    This software is distributed under the terms of the
    MOXA License.  See the file COPYING-MOXA for details.
*/

#ifndef __DX_API_H__
#define __DX_API_H__

#include <stdint.h>
#include <libmx-dx/dx_value.h>
#include <libmx-dx/binder.h>
#include <pthread.h>

typedef enum
{
    DX_TAG_OK = 0,
    DX_TAG_MALLOC_FAIL        = -1,
    DX_TAG_CREATE_THREAD_FAIL = -2,
    DX_TAG_CREATE_FAIL        = -3,
    DX_TAG_GET_FAIL           = -4,
    DX_TAG_SET_FAIL           = -5,
    DX_TAG_SUB_FAIL           = -6,
    DX_TAG_PUB_FAIL           = -7,
    DX_TAG_PUB_MAP_FAIL       = -8,
    DX_TAG_PUB_ASSEMBLE_FAIL  = -9,
    DX_TAG_TRY_AGAIN          = -10,
} DX_TAG_RET;

#define DX_TAG_MAX_HASH_TABLE_CNT   128

typedef struct DX_TAG_USER_INFO_t
{
    uint16_t    tag_len;
    char        *tag;
    void        *user_data;
    struct DX_TAG_USER_INFO_t *next;

} DX_TAG_USER_INFO, *DX_TAG_USER_INFO_p;

typedef struct DX_TAG_OBJ_t
{
    uint64_t            timestamp;
    uint16_t            tag_len;
    char                *tag;
    DX_TAG_VALUE_TYPE   val_type;
    DX_TAG_VALUE        val;
    void                *user_data;

} DX_TAG_OBJ, *DX_TAG_OBJ_P;

typedef void (*DX_TAG_SUB_CB)(DX_TAG_OBJ *dx_tag_obj, uint16_t obj_cnt, void *user_data);

typedef struct DX_TAG_CLIENT_t
{
    int32_t fd;
    char *module_name;
    int32_t state;

    DX_TAG_SUB_CB sub_cb;
    pthread_t thread;
    int32_t sub_thread_idx;
    uint32_t sub_buf_size;

    char *tag_buf;
    uint32_t tag_buf_size;
    DX_TAG_OBJ *tag_obj;
    uint32_t tag_obj_cnt;

    uint16_t user_info_enable;
    DX_TAG_USER_INFO *dx_tag_user_info[DX_TAG_MAX_HASH_TABLE_CNT];

    void *binder_info;
    void *user_data;
} DX_TAG_CLIENT, *DX_TAG_CLIENT_P;

DX_TAG_CLIENT* dx_tag_client_init(char* module_name,
                                  uint32_t name_size,
                                  DX_TAG_SUB_CB sub_cb,
                                  uint32_t buf_size);

DX_TAG_RET dx_tag_client_binder_reinit(DX_TAG_CLIENT *client);

void dx_tag_destroy(DX_TAG_CLIENT_P client);

DX_TAG_RET dx_tag_sub_callback_set(DX_TAG_CLIENT_P client, DX_TAG_SUB_CB sub_cb);

DX_TAG_RET dx_tag_user_data_set(DX_TAG_CLIENT_P client, void *obj);

DX_TAG_RET dx_tag_sub(DX_TAG_CLIENT_P client, char *tag, uint16_t tag_len, void *user_data);

DX_TAG_RET dx_tag_pub(DX_TAG_CLIENT_P client,
                      char *tag,
                      uint16_t tag_len,
                      DX_TAG_VALUE_TYPE val_type,
                      DX_TAG_VALUE val,
                      uint64_t ts);

DX_TAG_RET dx_tag_multi_pub(DX_TAG_CLIENT_P client, DX_TAG_OBJ* dx_obj, uint32_t dx_obj_cnt);

DX_TAG_RET dx_tag_get(DX_TAG_CLIENT_P client,
                      char *tag,
                      uint16_t tag_len,
                      DX_TAG_VALUE_TYPE *val_type,
                      DX_TAG_VALUE *val,
                      uint64_t *ts);

DX_TAG_RET dx_tag_get_list(DX_TAG_CLIENT_P client, DX_TAG_OBJ **dx_tag_obj, int32_t *obj_cnt);

DX_TAG_RET dx_tag_create(DX_TAG_CLIENT_P client,
                         char *tag,
                         uint16_t tag_len,
                         DX_TAG_VALUE_TYPE val_type,
                         DX_TAG_VALUE val,
                         uint64_t ts);

DX_TAG_RET dx_tag_delete(DX_TAG_CLIENT_P client, char *tag, uint16_t tag_len);

DX_TAG_VALUE_TYPE dx_tag_str2type(const char* type);

#endif /* __DX_API_H__ */
